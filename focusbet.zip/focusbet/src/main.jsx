/* ---------------------------------------------------------------------------
 *  BEFORE YOU SHIP: put your AdMob IDs in  src/config/appConfig.js
 *  (App ID, Banner Ad Unit ID, Rewarded Ad Unit ID, for Android and iOS).
 *  Swap placeholder images and sounds in  public/assets  (listed in
 *  src/config/assets.js). Full steps are in README.md.
 * ------------------------------------------------------------------------- */
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles/app.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
