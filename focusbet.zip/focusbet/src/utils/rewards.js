import { ECONOMY } from '../config/appConfig';

/** Coins earned for completing a bet of the given length. The rewarded ad doubles this amount. */
export function rewardForMinutes(minutes) {
  const m = Number(minutes);
  const fixed = ECONOMY.rewardByMinutes && ECONOMY.rewardByMinutes[m];
  return fixed || Math.max(1, Math.round(m * ECONOMY.coinsPerMinute));
}
