// Whole-day number for the user's local calendar date (stable across DST).
export function todayNumber(now = new Date()) {
  return Math.round(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 864e5);
}
