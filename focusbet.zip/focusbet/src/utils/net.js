/** Rejects with Error('timeout') after `ms` (and calls onTimeout, e.g. to abort the request). */
export function withTimeout(promise, ms, onTimeout = () => {}) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      onTimeout();
      reject(new Error('timeout'));
    }, ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
