import { WITHDRAWAL } from '../config/appConfig';

const INR = { minimumFractionDigits: 2, maximumFractionDigits: 2 };

export const formatCoins = (n) => Number(n).toLocaleString('en-IN');

/** 550 coins -> "₹5.50" (100 coins = ₹1). */
export const coinsToRupees = (coins) =>
  '₹' + (Math.max(0, Number(coins) || 0) / WITHDRAWAL.coinsPerRupee).toLocaleString('en-IN', INR);

export const canWithdraw = (coins) => coins >= WITHDRAWAL.minCoins;
export const coinsNeeded = (coins) => Math.max(0, WITHDRAWAL.minCoins - coins);

export const blockedMessage = (coins) =>
  `Minimum ${formatCoins(WITHDRAWAL.minCoins)} coins (${WITHDRAWAL.amountLabel}) required to withdraw. ` +
  `You need ${formatCoins(coinsNeeded(coins))} more coins to unlock your cash!`;

// name@bank. Must start with a letter or digit so a value can never be read as a spreadsheet formula.
const UPI_RE = /^[a-z0-9][a-z0-9._-]{1,255}@[a-z][a-z0-9]{1,63}$/;
export const normalizeUpi = (v) => String(v || '').trim().toLowerCase();
export const isValidUpi = (v) => UPI_RE.test(normalizeUpi(v));

export const newRequestId = () => {
  const rand =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 12)
      : Math.random().toString(36).slice(2, 14);
  return `wd-${Date.now().toString(36)}-${rand}`;
};
