import { useCallback, useEffect, useRef, useState } from 'react';
import { fetchStoreProducts } from '../services/products';

/** status: 'idle' | 'loading' | 'ready' | 'error'. Loads when `enabled` turns true. */
export function useStoreProducts(enabled) {
  const [status, setStatus] = useState('idle');
  const [items, setItems] = useState([]);
  const token = useRef(0);

  const load = useCallback(() => {
    const mine = ++token.current;
    setStatus('loading');
    fetchStoreProducts()
      .then((list) => {
        if (mine !== token.current) return;
        setItems(list);
        setStatus('ready');
      })
      .catch(() => {
        if (mine === token.current) setStatus('error');
      });
  }, []);

  useEffect(() => () => { token.current += 1; }, []);

  useEffect(() => {
    if (enabled && (status === 'idle' || status === 'error')) load();
  }, [enabled]); // eslint-disable-line react-hooks/exhaustive-deps

  return { status, items, reload: load };
}
