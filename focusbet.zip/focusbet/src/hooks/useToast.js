import { useCallback, useEffect, useRef, useState } from 'react';

export function useToast(durationMs = 2600) {
  const [text, setText] = useState('');
  const timer = useRef(null);

  const showToast = useCallback(
    (message) => {
      setText(message);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setText(''), durationMs);
    },
    [durationMs],
  );

  useEffect(() => () => clearTimeout(timer.current), []);

  return { toast: text, showToast };
}
