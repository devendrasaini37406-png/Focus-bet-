import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { APP, ECONOMY, WITHDRAWAL } from '../config/appConfig';
import { loadJson, saveJson, removeKey } from '../services/storage';
import { todayNumber } from '../utils/time';
import { canWithdraw, isValidUpi, newRequestId, normalizeUpi } from '../utils/withdraw';

const DEFAULT_STATE = {
  coins: ECONOMY.startingCoins,
  streak: 0,
  lastDay: null, // day number of the last winning bet
  owned: { neon: false, zen: false },
  equip: { neon: false, zen: false },
  shield: 0, // Streak Freeze Shields in stock
  adsRemoved: false,
  redeemed: [], // affiliate deal ids
  bet: null, // { active: true } while a bet is running (used to catch app kills)
  onboarded: false, // true after the first-launch tour
  withdrawals: [], // { id, upiId, createdAt, sent } cash requests; unsent ones are retried until delivered
};

const count = (v, fallback) => (Number.isFinite(v) && v >= 0 ? Math.floor(v) : fallback);

/** Rebuilds a safe state from whatever was saved, so corrupted storage can never break the app. */
function hydrate(saved) {
  const hadSave = Boolean(saved && typeof saved === 'object');
  const s = hadSave ? saved : {};
  const state = {
    coins: count(s.coins, DEFAULT_STATE.coins),
    streak: count(s.streak, 0),
    lastDay: Number.isFinite(s.lastDay) ? s.lastDay : null,
    owned: { ...DEFAULT_STATE.owned, ...(s.owned || {}) },
    equip: { ...DEFAULT_STATE.equip, ...(s.equip || {}) },
    shield: count(s.shield, 0),
    adsRemoved: s.adsRemoved === true,
    redeemed: Array.isArray(s.redeemed) ? s.redeemed.filter((id) => typeof id === 'string') : [],
    bet: s.bet && s.bet.active ? { active: true } : null,
    // Players who already have saved progress never see the first-launch tour.
    onboarded: s.onboarded === true || (hadSave && s.onboarded === undefined),
    withdrawals: Array.isArray(s.withdrawals)
      ? s.withdrawals
          .filter((w) => w && typeof w.id === 'string' && typeof w.upiId === 'string' && typeof w.createdAt === 'string')
          .map((w) => ({ id: w.id, upiId: w.upiId, createdAt: w.createdAt, sent: w.sent === true }))
      : [],
  };
  // A full missed day breaks the streak.
  if (state.lastDay !== null && todayNumber() - state.lastDay >= 2) state.streak = 0;
  return state;
}

/** Persistent game state plus every action that changes it. */
export function useGameState() {
  const [state, setState] = useState(null);
  const ref = useRef(null);

  const commit = useCallback((next) => {
    ref.current = next;
    setState(next);
    saveJson(APP.storageKey, next);
  }, []);

  useEffect(() => {
    let alive = true;
    loadJson(APP.storageKey, null).then((saved) => {
      if (!alive) return;
      const next = hydrate(saved);
      ref.current = next;
      setState(next);
    });
    return () => {
      alive = false;
    };
  }, []);

  const actions = useMemo(
    () => ({
      getState: () => ref.current,

      startBet() {
        commit({ ...ref.current, bet: { active: true } });
      },

      applyWin(reward) {
        const s = ref.current;
        const coins = Number.isFinite(reward) && reward > 0 ? Math.floor(reward) : 0;
        const today = todayNumber();
        const gap = s.lastDay === null ? null : today - s.lastDay;
        const next = { ...s, coins: s.coins + coins, bet: null };
        // One streak day per calendar day. A negative gap means the clock was moved back: no bonus.
        if (gap === null || gap >= 1) {
          next.streak = gap !== null && gap >= 2 ? 1 : s.streak + 1;
          next.lastDay = today;
        }
        commit(next);
      },

      /** Returns true if a Streak Freeze Shield saved the streak. */
      applyFail() {
        const s = ref.current;
        const next = { ...s, coins: Math.max(0, s.coins - ECONOMY.betCost), bet: null };
        let saved = false;
        if (s.shield > 0) {
          next.shield = s.shield - 1;
          saved = true;
        } else {
          next.streak = 0;
        }
        commit(next);
        return saved;
      },

      addCoins(n) {
        if (!Number.isFinite(n) || n <= 0) return;
        commit({ ...ref.current, coins: ref.current.coins + Math.floor(n) });
      },

      buyItem(item) {
        const s = ref.current;
        if (!Number.isFinite(item.cost) || s.coins < item.cost) return false;
        // Never charge twice for something already owned.
        if (item.id === 'shield' ? s.shield > 0 : s.owned[item.id]) return false;
        const next = { ...s, coins: s.coins - item.cost };
        if (item.id === 'shield') next.shield = 1;
        else {
          next.owned = { ...s.owned, [item.id]: true };
          next.equip = { ...s.equip, [item.id]: true };
        }
        commit(next);
        return true;
      },

      toggleEquip(id) {
        const s = ref.current;
        if (!s.owned[id]) return;
        commit({ ...s, equip: { ...s.equip, [id]: !s.equip[id] } });
      },

      redeemDeal(deal) {
        const s = ref.current;
        if (s.coins < deal.coinsRequired || s.redeemed.includes(deal.id)) return false;
        commit({ ...s, coins: s.coins - deal.coinsRequired, redeemed: [...s.redeemed, deal.id] });
        return true;
      },

      /**
       * Deducts exactly WITHDRAWAL.coinCost and queues the request. Returns the request, or null if the
       * balance is too low or the UPI ID is invalid. The balance is saved immediately.
       */
      requestWithdrawal(upiId) {
        const s = ref.current;
        if (!canWithdraw(s.coins) || s.coins < WITHDRAWAL.coinCost || !isValidUpi(upiId)) return null;
        const request = { id: newRequestId(), upiId: normalizeUpi(upiId), createdAt: new Date().toISOString(), sent: false };
        commit({ ...s, coins: s.coins - WITHDRAWAL.coinCost, withdrawals: [...s.withdrawals, request] });
        return request;
      },

      markWithdrawalSent(id) {
        const s = ref.current;
        const marked = s.withdrawals.map((w) => (w.id === id ? { ...w, sent: true } : w));
        // keep every unsent request, but only the 20 most recent delivered ones
        const sentList = marked.filter((w) => w.sent).slice(-20);
        commit({ ...s, withdrawals: [...marked.filter((w) => !w.sent), ...sentList] });
      },

      completeOnboarding() {
        commit({ ...ref.current, onboarded: true });
      },

      setAdsRemoved() {
        commit({ ...ref.current, adsRemoved: true });
      },

      async reset() {
        await removeKey(APP.storageKey);
        commit(hydrate(null));
      },
    }),
    [commit],
  );

  return { state, actions };
}
