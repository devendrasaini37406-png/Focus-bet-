import { useEffect, useState } from 'react';
import { WITHDRAWAL } from '../config/appConfig';
import { flushWithdrawals } from '../services/withdrawals';

/**
 * Keeps trying to deliver queued withdrawal requests: right away, whenever the phone comes back online,
 * and every WITHDRAWAL.retryMs while any request is still waiting. Stops by itself when the queue is empty.
 */
export function useWithdrawalSync(state, actions) {
  const waiting = state ? state.withdrawals.filter((w) => !w.sent).length : 0;
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!waiting) return undefined;
    flushWithdrawals(actions.getState().withdrawals, actions.markWithdrawalSent);
    const retry = setTimeout(() => setAttempt((n) => n + 1), WITHDRAWAL.retryMs);
    const onOnline = () => setAttempt((n) => n + 1);
    window.addEventListener('online', onOnline);
    return () => {
      clearTimeout(retry);
      window.removeEventListener('online', onOnline);
    };
  }, [waiting, attempt, actions]);
}
