import { useCallback, useEffect, useRef, useState } from 'react';
import { TIMER } from '../config/appConfig';

/**
 * Countdown that cannot be shortened by changing the phone clock.
 * Elapsed time is measured with performance.now() (monotonic). Every tick the
 * wall clock (Date.now) is compared against it; a gap larger than
 * TIMER.clockDriftMs means the system time was changed and onTamper() fires.
 */
export function useFocusTimer({ onComplete, onTamper }) {
  const [selectedMin, setSelectedMin] = useState(null);
  const [totalSec, setTotalSec] = useState(TIMER.defaultMin * 60);
  const [remaining, setRemaining] = useState(TIMER.defaultMin * 60);
  const [running, setRunning] = useState(false);

  const t = useRef({ iv: null, elapsed: 0, durMs: 0, lastMono: 0, lastWall: 0, totalSec });
  t.current.totalSec = totalSec;

  const callbacks = useRef({});
  callbacks.current = { onComplete, onTamper };

  const clear = useCallback(() => {
    clearInterval(t.current.iv);
    t.current.iv = null;
  }, []);

  const tick = useCallback(() => {
    const s = t.current;
    const mono = performance.now();
    const wall = Date.now();
    const dMono = mono - s.lastMono;
    const dWall = wall - s.lastWall;

    if (Math.abs(dWall - dMono) > TIMER.clockDriftMs) {
      clear();
      setRunning(false);
      callbacks.current.onTamper();
      return;
    }

    s.elapsed += dMono;
    s.lastMono = mono;
    s.lastWall = wall;
    setRemaining(Math.max(0, Math.ceil((s.durMs - s.elapsed) / 1000)));

    if (s.elapsed >= s.durMs) {
      clear();
      setRunning(false);
      callbacks.current.onComplete();
    }
  }, [clear]);

  const begin = useCallback(() => {
    t.current.lastMono = performance.now();
    t.current.lastWall = Date.now();
    clear();
    t.current.iv = setInterval(tick, 250);
    setRunning(true);
  }, [clear, tick]);

  const start = useCallback(() => {
    t.current.durMs = t.current.totalSec * 1000;
    t.current.elapsed = 0;
    setRemaining(t.current.totalSec);
    begin();
  }, [begin]);

  const pause = useCallback(() => {
    const s = t.current;
    if (!s.iv) return;
    const mono = performance.now();
    s.elapsed += mono - s.lastMono;
    s.lastMono = mono;
    clear();
    setRunning(false);
    setRemaining(Math.max(0, Math.ceil((s.durMs - s.elapsed) / 1000)));
  }, [clear]);

  const resume = useCallback(() => begin(), [begin]);

  const reset = useCallback(() => {
    clear();
    t.current.elapsed = 0;
    setRunning(false);
    setRemaining(t.current.totalSec);
  }, [clear]);

  const select = useCallback((min) => {
    if (t.current.iv) return; // the length can't be changed mid-bet
    setSelectedMin(min);
    setTotalSec(min * 60);
    setRemaining(min * 60);
  }, []);

  useEffect(() => clear, [clear]);

  return { remaining, totalSec, running, selectedMin, select, start, pause, resume, reset };
}
