import { useCallback, useEffect, useRef, useState } from 'react';
import { ECONOMY, TIMER, WITHDRAWAL } from './config/appConfig';
import { ASSETS } from './config/assets';
import { useGameState } from './hooks/useGameState';
import { useFocusTimer } from './hooks/useFocusTimer';
import { useToast } from './hooks/useToast';
import { useWithdrawalSync } from './hooks/useWithdrawalSync';
import { watchLifecycle } from './services/lifecycle';
import { playAmbient, stopAmbient, playChime, stopChime } from './services/audio';
import { initAds, showBanner, hideBanner, showRewardedAd, isNative } from './services/ads';
import { purchaseRemoveAds } from './services/billing';
import { isWithdrawalConfigured } from './services/withdrawals';
import { canWithdraw } from './utils/withdraw';
import { rewardForMinutes } from './utils/rewards';

import Header from './components/Header/Header';
import StreakBar from './components/Header/StreakBar';
import WalletCard from './components/Wallet/WalletCard';
import CircularTimer from './components/Timer/CircularTimer';
import PresetSelector from './components/Timer/PresetSelector';
import ActionButton from './components/Timer/ActionButton';
import BannerSlot from './components/Ads/BannerSlot';
import RewardedAdOverlay from './components/Ads/RewardedAdOverlay';
import PaymentScreen from './components/Payment/PaymentScreen';
import ShopSheet from './components/Shop/ShopSheet';
import WinModal from './components/Modals/WinModal';
import QuitConfirmModal from './components/Modals/QuitConfirmModal';
import FailModal from './components/Modals/FailModal';
import BatteryModal from './components/Modals/BatteryModal';
import WithdrawModal from './components/Modals/WithdrawModal';
import WithdrawBlockedModal from './components/Modals/WithdrawBlockedModal';
import SplashScreen from './components/Welcome/SplashScreen';
import Onboarding from './components/Welcome/Onboarding';
import Greeting from './components/Home/Greeting';
import Toast from './components/Common/Toast';
import Confetti from './components/Common/Confetti';

// status: 'idle' | 'running' | 'confirm' | 'grace' | 'ended'
export default function App() {
  const { state, actions } = useGameState();
  const { toast, showToast } = useToast();
  useWithdrawalSync(state, actions); // delivers queued cash requests whenever possible
  const [introDone, setIntroDone] = useState(false);
  const finishIntro = useCallback(() => setIntroDone(true), []);

  const [status, setStatusState] = useState('idle');
  const statusRef = useRef('idle');
  const setStatus = useCallback((s) => {
    statusRef.current = s;
    setStatusState(s);
  }, []);

  const [modal, setModal] = useState(null); // { type, ...data }
  const [shopOpen, setShopOpen] = useState(false);
  const [payment, setPayment] = useState(null); // { state, orderId }
  const [simulatedAd, setSimulatedAd] = useState(false);
  const [confettiKey, setConfettiKey] = useState(0);
  const graceTimer = useRef(null);
  const rewardRef = useRef(0); // coins earned by the bet that just ended (the ad doubles this)
  const recovered = useRef(false);

  /* ---------- bet outcomes ---------- */
  const startAmbientIfOwned = useCallback(() => {
    if (actions.getState().equip.zen) playAmbient(ASSETS.sounds.zenForest);
  }, [actions]);

  const handleComplete = useCallback(() => {
    if (statusRef.current !== 'running') return;
    stopAmbient();
    playChime(ASSETS.sounds.timerEnd);
    const reward = rewardForMinutes(timerRef.current.totalSec / 60);
    rewardRef.current = reward;
    actions.applyWin(reward);
    setStatus('ended');
    setConfettiKey((k) => k + 1);
    setModal({ type: 'win', reward, busy: false });
  }, [actions, setStatus]);

  const timerRef = useRef(null);

  const failBet = useCallback(
    (reason) => {
      if (!['running', 'grace', 'confirm'].includes(statusRef.current)) return;
      clearTimeout(graceTimer.current);
      stopAmbient();
      const saved = actions.applyFail();
      timerRef.current.reset();
      setStatus('ended');
      setModal({ type: 'fail', reason, saved });
    },
    [actions, setStatus],
  );

  const timer = useFocusTimer({ onComplete: handleComplete, onTamper: () => failBet('clock') });
  timerRef.current = timer;

  /* ---------- start, give up ---------- */
  const startBet = () => {
    if (statusRef.current !== 'idle') return;
    if (state.coins < ECONOMY.betCost) return showToast(`You need at least ${ECONOMY.betCost} coins to place a bet`);
    actions.startBet();
    timer.start();
    setStatus('running');
    startAmbientIfOwned();
  };

  const askGiveUp = () => {
    if (statusRef.current !== 'running') return;
    timer.pause();
    stopAmbient();
    setStatus('confirm');
    setModal({ type: 'quit' });
  };

  const keepFocusing = () => {
    setModal(null);
    setStatus('running');
    timer.resume();
    startAmbientIfOwned();
  };

  const confirmQuit = () => {
    const saved = actions.applyFail();
    timer.reset();
    setModal(null);
    setStatus('idle');
    showToast(saved ? 'Bet lost. Your Streak Freeze Shield protected your streak.' : 'Bet lost. Your streak was reset.');
  };

  /* ---------- app lifecycle: leaving the app, lock, notifications ---------- */
  useEffect(
    () =>
      watchLifecycle({
        onBackground: () => {
          if (['running', 'grace', 'confirm'].includes(statusRef.current)) failBet('background');
        },
        onInterrupt: (kind) => {
          if (statusRef.current !== 'running') return;
          timerRef.current.pause();
          stopAmbient();
          setStatus('grace');
          clearTimeout(graceTimer.current);
          graceTimer.current = setTimeout(() => {
            if (statusRef.current === 'grace') failBet(kind);
          }, TIMER.graceMs);
        },
        onForeground: () => {
          if (statusRef.current !== 'grace') return;
          clearTimeout(graceTimer.current);
          timerRef.current.resume();
          setStatus('running');
          if (actions.getState().equip.zen) playAmbient(ASSETS.sounds.zenForest);
          showToast('Welcome back, bet resumed');
        },
      }),
    [actions, failBet, setStatus, showToast],
  );

  /* ---------- app was killed during a bet ---------- */
  useEffect(() => {
    if (!state || recovered.current) return;
    recovered.current = true;
    if (state.bet && state.bet.active) {
      const saved = actions.applyFail();
      setModal({ type: 'fail', reason: 'killed', saved });
    }
  }, [state, actions]);

  /* ---------- ads ---------- */
  useEffect(() => {
    initAds().catch(() => {});
  }, []);

  useEffect(() => {
    if (!state) return;
    if (state.adsRemoved) hideBanner();
    else showBanner();
  }, [state && state.adsRemoved]); // eslint-disable-line react-hooks/exhaustive-deps

  const finishDouble = useCallback(
    (earned) => {
      setSimulatedAd(false);
      if (earned) {
        actions.addCoins(rewardRef.current);
        setConfettiKey((k) => k + 1);
        setModal(null);
        timerRef.current.reset();
        setStatus('idle');
        showToast('Ad Watched! Coins doubled!');
      } else {
        setModal((m) => (m ? { ...m, busy: false } : m));
        showToast('Ad not available. Try again later.');
      }
    },
    [actions, setStatus, showToast],
  );

  const doubleCoins = async () => {
    stopChime();
    setModal((m) => ({ ...m, busy: true }));
    if (isNative) finishDouble(await showRewardedAd());
    else setSimulatedAd(true);
  };

  /* ---------- in-app purchase ---------- */
  const removeAds = async () => {
    if (payment) return;
    setPayment({ state: 'processing' });
    let result;
    try {
      result = await purchaseRemoveAds();
    } catch {
      result = { success: false };
    }
    if (result && result.success) {
      actions.setAdsRemoved();
      setPayment({ state: 'success', orderId: result.orderId });
    } else {
      setPayment(null);
      showToast('The payment did not complete. Please try again.');
    }
  };

  /* ---------- misc handlers ---------- */
  const openShop = () => (status === 'idle' ? setShopOpen(true) : showToast('Finish or quit your current bet first'));
  const openSettings = () => (status === 'idle' ? setModal({ type: 'battery' }) : showToast('Finish your bet first'));
  const openWithdraw = () => {
    if (statusRef.current !== 'idle') return showToast('Finish or quit your current bet first');
    if (!canWithdraw(state.coins)) return setModal({ type: 'withdrawBlocked' });
    // Release builds never take coins for a request that cannot be delivered. Dev builds still open the form.
    if (import.meta.env.PROD && !isWithdrawalConfigured()) {
      return showToast('Withdrawals are not available yet. Please try again later.');
    }
    return setModal({ type: 'withdraw' });
  };
  const submitWithdraw = (upiId) => {
    const request = actions.requestWithdrawal(upiId); // deducts the coins and saves right away
    setModal(null);
    showToast(
      request
        ? `Request Submitted! ${WITHDRAWAL.amountLabel} will be sent to your UPI ID soon.`
        : 'Could not submit your request. Please check your balance and UPI ID.',
    );
  };
  const closeToIdle = () => {
    stopChime();
    setModal(null);
    timerRef.current.reset();
    setStatus('idle');
  };

  // Opening animation first (and until saved data has loaded), then the one-time tour.
  if (!state || !introDone) return <SplashScreen onDone={finishIntro} />;
  if (!state.onboarded) return <Onboarding onDone={actions.completeOnboarding} />;

  const running = status === 'running' || status === 'grace' || status === 'confirm';
  const graceSeconds = Math.round(TIMER.graceMs / 1000);
  const subtitle = status === 'grace' ? `Paused. Come back in ${graceSeconds}s` : running ? "You've got this" : 'Ready to focus';

  return (
    <div className={`app ${state.equip.neon ? 'neon' : ''} ${state.adsRemoved ? 'no-ads' : ''}`}>
      <Header onSettings={openSettings} onShop={openShop} />
      <WalletCard coins={state.coins} onWithdraw={openWithdraw} />

      <Greeting streak={state.streak} running={running} />

      <CircularTimer remaining={timer.remaining} total={timer.totalSec} subtitle={subtitle} active={running} />

      <PresetSelector
        presets={TIMER.presetsMin}
        selected={timer.selectedMin}
        disabled={status !== 'idle'}
        onSelect={timer.select}
      />

      <ActionButton running={running} onStart={startBet} onGiveUp={askGiveUp} />
      <StreakBar streak={state.streak} shielded={state.shield > 0} />

      {!state.adsRemoved && <BannerSlot />}

      <Confetti burstKey={confettiKey} />

      <ShopSheet
        open={shopOpen}
        state={state}
        actions={actions}
        onClose={() => setShopOpen(false)}
        onRemoveAds={removeAds}
        onToast={showToast}
      />

      {modal && modal.type === 'win' && (
        <WinModal reward={modal.reward} busy={modal.busy} onClose={closeToIdle} onDouble={doubleCoins} />
      )}
      {modal && modal.type === 'quit' && (
        <QuitConfirmModal shieldActive={state.shield > 0} onConfirm={confirmQuit} onKeep={keepFocusing} />
      )}
      {modal && modal.type === 'fail' && <FailModal reason={modal.reason} shieldSaved={modal.saved} onClose={closeToIdle} />}
      {modal && modal.type === 'battery' && <BatteryModal onClose={() => setModal(null)} />}
      {modal && modal.type === 'withdraw' && <WithdrawModal onSubmit={submitWithdraw} onCancel={() => setModal(null)} />}
      {modal && modal.type === 'withdrawBlocked' && (
        <WithdrawBlockedModal coins={state.coins} onClose={() => setModal(null)} />
      )}

      {payment && (
        <PaymentScreen
          state={payment.state}
          orderId={payment.orderId}
          onDone={() => setPayment(null)}
        />
      )}
      {simulatedAd && <RewardedAdOverlay onDone={() => finishDouble(true)} />}

      <Toast text={toast} />
    </div>
  );
}
