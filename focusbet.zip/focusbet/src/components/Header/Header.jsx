import { Settings, ShoppingBag } from '../Common/Icons';

export default function Header({ onSettings, onShop }) {
  return (
    <header className="header">
      <div className="header-left">
        <button className="icon-btn" aria-label="Settings" onClick={onSettings}>
          <Settings size={18} aria-hidden="true" />
        </button>
        <span className="brand">
          Focus<span className="accent">Bet</span>
        </span>
      </div>
      <button className="shop-btn" aria-label="Open shop" onClick={onShop}>
        <ShoppingBag size={16} aria-hidden="true" />
        Shop
      </button>
    </header>
  );
}
