import { Flame, Shield } from '../Common/Icons';

export default function StreakBar({ streak, shielded }) {
  return (
    <div className="streak">
      <Flame size={18} className="accent" aria-hidden="true" />
      <span>{streak > 0 ? `${streak} Day Focus Streak!` : 'Start your focus streak today!'}</span>
      {shielded && (
        <span className="streak-shield">
          <Shield size={15} aria-hidden="true" /> Shield ready
        </span>
      )}
    </div>
  );
}
