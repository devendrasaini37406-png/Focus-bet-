import { useEffect } from 'react';
import { ASSETS } from '../../config/assets';

const reduceMotion = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** Opening animation: a ring draws itself around a bouncing coin, then the wordmark and tagline appear. */
export default function SplashScreen({ onDone }) {
  useEffect(() => {
    const id = setTimeout(onDone, reduceMotion() ? 700 : 2200);
    return () => clearTimeout(id);
  }, [onDone]);

  return (
    <div className="intro splash" role="status" aria-label="FocusBet is loading">
      <span className="splash-coin c1" aria-hidden="true"><img src={ASSETS.icons.coin} alt="" width="22" height="22" /></span>
      <span className="splash-coin c2" aria-hidden="true"><img src={ASSETS.icons.coin} alt="" width="16" height="16" /></span>
      <span className="splash-coin c3" aria-hidden="true"><img src={ASSETS.icons.coin} alt="" width="26" height="26" /></span>

      <div className="splash-emblem" aria-hidden="true">
        <svg viewBox="0 0 120 120" width="150" height="150">
          <circle className="splash-track" cx="60" cy="60" r="50" fill="none" strokeWidth="7" />
          <circle className="splash-arc" cx="60" cy="60" r="50" fill="none" strokeWidth="7" strokeLinecap="round" transform="rotate(-90 60 60)" />
        </svg>
        <img className="splash-mid" src={ASSETS.icons.coin} alt="" width="58" height="58" />
      </div>

      <h1 className="splash-word">
        Focus<span className="accent">Bet</span>
      </h1>
      <p className="splash-tag">Bet on your focus. Win your time.</p>
    </div>
  );
}
