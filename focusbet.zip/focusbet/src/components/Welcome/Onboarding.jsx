import { useEffect, useRef, useState } from 'react';
import { Gift, Timer, Trophy } from '../Common/Icons';
import { ECONOMY, TIMER, WITHDRAWAL } from '../../config/appConfig';
import { rewardForMinutes } from '../../utils/rewards';

const presets = TIMER.presetsMin;
const SLIDES = [
  {
    Icon: Timer,
    title: 'Pick your focus time',
    text: `Choose ${presets[0]} to ${presets[presets.length - 1]} minutes, then start a Focus Bet. You put ${ECONOMY.betCost} coins on the line to keep yourself honest.`,
  },
  {
    Icon: Trophy,
    title: 'Stay focused, win coins',
    text: `Finish the countdown without leaving the app and you earn coins based on how long you focus, starting at ${rewardForMinutes(presets[0])} coins. Leave early and the bet is lost, so stay with it.`,
  },
  {
    Icon: Gift,
    title: 'Turn focus into rewards',
    text: `Spend coins on themes and exclusive deals. Collect ${WITHDRAWAL.minCoins.toLocaleString('en-IN')} coins to withdraw ${WITHDRAWAL.amountLabel} to your UPI.`,
  },
];

/** First-launch tour: three short slides. Skippable at any time. */
export default function Onboarding({ onDone }) {
  const [i, setI] = useState(0);
  const heading = useRef(null);
  const last = i === SLIDES.length - 1;
  const { Icon, title, text } = SLIDES[i];

  // Keyboard and screen-reader users land on the new slide's heading.
  useEffect(() => {
    if (heading.current) heading.current.focus();
  }, [i]);

  return (
    <main className="intro onb" aria-label="Welcome to FocusBet">
      <div className="onb-top">
        <span className="brand">
          Focus<span className="accent">Bet</span>
        </span>
        {!last && (
          <button className="onb-skip" onClick={onDone}>
            Skip
          </button>
        )}
      </div>

      <section className="onb-slide" key={i} aria-roledescription="slide" aria-label={`Step ${i + 1} of ${SLIDES.length}`}>
        <div className="onb-art" aria-hidden="true">
          <Icon size={64} strokeWidth={1.6} />
        </div>
        <h1 className="onb-title" ref={heading} tabIndex={-1}>
          {title}
        </h1>
        <p className="onb-text">{text}</p>
      </section>

      <div className="onb-dots" aria-hidden="true">
        {SLIDES.map((_, n) => (
          <span key={n} className={`onb-dot ${n === i ? 'on' : ''}`} />
        ))}
      </div>

      <button className="btn primary onb-next" onClick={() => (last ? onDone() : setI(i + 1))}>
        {last ? 'Start focusing' : 'Next'}
      </button>
    </main>
  );
}
