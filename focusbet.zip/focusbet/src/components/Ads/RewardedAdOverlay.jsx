import { useEffect, useRef, useState } from 'react';
import { Play } from '../Common/Icons';
import { TIMER } from '../../config/appConfig';

/* Browser-preview stand-in for the rewarded video. On device the real AdMob ad
 * is shown instead (see services/ads.js) and this overlay is never rendered. */
export default function RewardedAdOverlay({ onDone }) {
  const [left, setLeft] = useState(TIMER.simulatedAdSeconds);
  const doneRef = useRef(onDone); // always call the latest handler without restarting the countdown
  doneRef.current = onDone;
  const finished = useRef(false); // the reward can only be granted once

  useEffect(() => {
    if (left <= 0) {
      if (!finished.current) {
        finished.current = true;
        doneRef.current();
      }
      return undefined;
    }
    const id = setTimeout(() => setLeft((n) => n - 1), 1000);
    return () => clearTimeout(id);
  }, [left]);

  const pct = ((TIMER.simulatedAdSeconds - left) / TIMER.simulatedAdSeconds) * 100;

  return (
    <div className="ad-overlay" role="dialog" aria-modal="true" aria-label="Rewarded video ad">
      <div className="ad-top">
        <span className="ad-tag">Ad</span>
        <span className="ad-count">Reward in {left}s</span>
      </div>
      <div className="ad-body">
        <Play size={56} aria-hidden="true" />
        <span>Simulated rewarded video ad</span>
      </div>
      <div className="ad-bar" aria-hidden="true">
        <div style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
