import { isNative } from '../../services/ads';

/* Reserves the 50px banner strip. On device the real AdMob banner is drawn
 * over this space; in the browser preview a labelled placeholder shows instead. */
export default function BannerSlot() {
  return <div className="banner-slot">{!isNative && '[Google AdMob Banner Ad Holder]'}</div>;
}
