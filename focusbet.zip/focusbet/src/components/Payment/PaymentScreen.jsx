import { useEffect, useRef } from 'react';
import { Check, Loader2 } from '../Common/Icons';
import { IAP } from '../../config/appConfig';

export default function PaymentScreen({ state, orderId, onDone }) {
  const doneRef = useRef(null);
  useEffect(() => {
    if (state !== 'processing' && doneRef.current) doneRef.current.focus();
  }, [state]);

  if (state === 'processing') {
    return (
      <div className="pay" role="dialog" aria-modal="true" aria-label="Processing payment" aria-busy="true">
        <Loader2 size={40} className="accent spin" aria-hidden="true" />
        <p className="pay-text" role="status">
          Processing payment...
        </p>
      </div>
    );
  }
  return (
    <div className="pay" role="dialog" aria-modal="true" aria-label="Payment successful">
      <div className="pay-check" aria-hidden="true">
        <Check size={40} />
      </div>
      <h2 className="pay-title">Payment successful</h2>
      <p className="pay-text">
        Remove Ads - {IAP.priceLabel}
        <br />
        Ads are now removed for good. Thank you for supporting FocusBet!
      </p>
      <p className="pay-order">Order ID: {orderId}</p>
      <button ref={doneRef} className="btn primary pay-done" onClick={onDone}>
        Done
      </button>
    </div>
  );
}
