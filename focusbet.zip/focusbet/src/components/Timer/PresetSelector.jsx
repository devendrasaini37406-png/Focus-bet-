import { rewardForMinutes } from '../../utils/rewards';

export default function PresetSelector({ presets, selected, disabled, onSelect }) {
  return (
    <div className="presets" role="group" aria-label="Focus duration">
      {presets.map((min) => (
        <button
          key={min}
          className={`preset ${selected === min ? 'on' : ''}`}
          disabled={disabled}
          aria-pressed={selected === min}
          aria-label={`${min} minutes, earns ${rewardForMinutes(min)} coins`}
          onClick={() => onSelect(min)}
        >
          <span className="preset-min">{min} min</span>
          <span className="preset-win">+{rewardForMinutes(min)} coins</span>
        </button>
      ))}
    </div>
  );
}
