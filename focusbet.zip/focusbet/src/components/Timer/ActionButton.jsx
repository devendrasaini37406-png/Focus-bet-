export default function ActionButton({ running, onStart, onGiveUp }) {
  return running ? (
    <button className="action give-up" onClick={onGiveUp}>
      Give Up & Lose Bet
    </button>
  ) : (
    <button className="action" onClick={onStart}>
      Start Focus Bet
    </button>
  );
}
