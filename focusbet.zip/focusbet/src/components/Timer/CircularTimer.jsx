import { formatTime } from '../../utils/format';

const R = 104;
const CIRC = 2 * Math.PI * R;

export default function CircularTimer({ remaining, total, subtitle, active = false }) {
  const progress = total > 0 ? remaining / total : 0;
  return (
    <div className={`timer ${active ? 'active' : ''}`} role="timer" aria-label={`${formatTime(remaining)} remaining`}>
      <svg viewBox="0 0 240 240" width="240" height="240" aria-hidden="true">
        <circle className="timer-track" cx="120" cy="120" r={R} fill="none" strokeWidth="10" />
        <circle
          className="timer-ring"
          cx="120"
          cy="120"
          r={R}
          fill="none"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={CIRC}
          strokeDashoffset={CIRC * (1 - progress)}
          transform="rotate(-90 120 120)"
        />
      </svg>
      <div className="timer-center">
        <span className="timer-time">{formatTime(remaining)}</span>
        <span className="timer-sub" aria-live="polite">
          {subtitle}
        </span>
      </div>
    </div>
  );
}
