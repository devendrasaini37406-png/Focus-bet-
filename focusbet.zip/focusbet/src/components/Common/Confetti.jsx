import { useEffect, useRef } from 'react';

const COLORS = ['#3DF5B5', '#FFFFFF', '#FFC857', '#7AA2FF', '#FF8FA3'];

/** Fires a burst every time `burstKey` changes (and is > 0). */
export default function Confetti({ burstKey }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!burstKey) return undefined;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const parts = Array.from({ length: 140 }, (_, i) => ({
      x: canvas.width / 2 + (Math.random() - 0.5) * 60,
      y: canvas.height * 0.4,
      vx: (Math.random() - 0.5) * 12,
      vy: -Math.random() * 13 - 3,
      w: 5 + Math.random() * 6,
      h: 8 + Math.random() * 6,
      a: Math.random() * 6,
      va: (Math.random() - 0.5) * 0.4,
      c: COLORS[i % COLORS.length],
      life: 0,
    }));

    let raf;
    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = 0;
      for (const p of parts) {
        p.life += 1;
        p.vy += 0.35;
        p.vx *= 0.99;
        p.x += p.vx;
        p.y += p.vy;
        p.a += p.va;
        if (p.y < canvas.height + 20 && p.life < 200) {
          alive += 1;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.a);
          ctx.fillStyle = p.c;
          ctx.globalAlpha = Math.max(0, 1 - p.life / 200);
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          ctx.restore();
        }
      }
      if (alive) raf = requestAnimationFrame(loop);
      else ctx.clearRect(0, 0, canvas.width, canvas.height);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [burstKey]);

  return <canvas ref={canvasRef} className="confetti" aria-hidden="true" />;
}
