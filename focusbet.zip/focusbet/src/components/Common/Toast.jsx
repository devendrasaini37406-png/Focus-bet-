export default function Toast({ text }) {
  return (
    <div className={`toast ${text ? 'show' : ''}`} role="status" aria-live="polite">
      {text}
    </div>
  );
}
