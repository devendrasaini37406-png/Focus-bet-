import { Lock } from '../Common/Icons';
import ModalShell from './ModalShell';
import { blockedMessage } from '../../utils/withdraw';

export default function WithdrawBlockedModal({ coins, onClose }) {
  return (
    <ModalShell label="Withdrawal locked" alert>
      <div className="modal-icon accent round" aria-hidden="true">
        <Lock size={28} />
      </div>
      <h2 className="modal-title">Almost there!</h2>
      <p className="modal-text">{blockedMessage(coins)}</p>
      <button className="btn primary" onClick={onClose} data-autofocus>
        OK
      </button>
    </ModalShell>
  );
}
