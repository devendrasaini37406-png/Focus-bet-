import { useRef, useState } from 'react';
import ModalShell from './ModalShell';
import { WITHDRAWAL } from '../../config/appConfig';
import { formatCoins, isValidUpi, normalizeUpi } from '../../utils/withdraw';

export default function WithdrawModal({ onSubmit, onCancel }) {
  const [upi, setUpi] = useState('');
  const [error, setError] = useState('');
  const submitted = useRef(false); // a double tap must never submit twice

  const submit = (e) => {
    e.preventDefault();
    if (submitted.current) return;
    if (!isValidUpi(upi)) {
      setError('Enter a valid UPI ID, for example name@bank.');
      return;
    }
    submitted.current = true;
    onSubmit(normalizeUpi(upi));
  };

  return (
    <ModalShell label="Withdraw cash">
      <h2 className="modal-title">Withdraw Cash</h2>
      <p className="modal-text">
        {formatCoins(WITHDRAWAL.coinCost)} coins = {WITHDRAWAL.amountLabel}, sent to your UPI ID.
      </p>
      <form onSubmit={submit} noValidate className="form">
        <label className="field-label" htmlFor="upi-id">
          UPI ID
        </label>
        <input
          id="upi-id"
          className="field"
          type="text"
          inputMode="email"
          autoComplete="off"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
          maxLength={256}
          placeholder="yourname@bank"
          value={upi}
          onChange={(e) => {
            setUpi(e.target.value);
            if (error) setError('');
          }}
          aria-invalid={error ? 'true' : 'false'}
          aria-describedby={error ? 'upi-error' : undefined}
        />
        {error && (
          <p id="upi-error" className="field-error" role="alert">
            {error}
          </p>
        )}
        <button type="submit" className="btn primary">
          Submit
        </button>
        <button type="button" className="btn muted" onClick={onCancel}>
          Cancel
        </button>
      </form>
    </ModalShell>
  );
}
