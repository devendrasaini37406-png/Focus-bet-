import ModalShell from './ModalShell';

export default function QuitConfirmModal({ shieldActive, onConfirm, onKeep }) {
  return (
    <ModalShell label="Quit this bet" alert>
      <h2 className="modal-title">Quit this bet?</h2>
      <p className="modal-text">Are you sure you want to quit? You will lose this bet and break your streak.</p>
      {shieldActive && <p className="modal-note">Your Streak Freeze Shield will protect your streak once.</p>}
      <button className="btn muted" onClick={onKeep} data-autofocus>
        Keep focusing
      </button>
      <button className="btn danger" onClick={onConfirm}>
        Yes, quit
      </button>
    </ModalShell>
  );
}
