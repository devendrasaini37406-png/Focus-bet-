import { Trophy } from '../Common/Icons';
import ModalShell from './ModalShell';

export default function WinModal({ reward, busy, onClose, onDouble }) {
  return (
    <ModalShell label="Bet won">
      <div className="modal-icon accent" aria-hidden="true">
        <Trophy size={40} />
      </div>
      <h2 className="modal-title accent">Bet Won!</h2>
      <p className="modal-text big">
        You earned +{reward} Coins! <span aria-hidden="true">🪙</span>
      </p>
      <button className="btn primary" onClick={onClose} disabled={busy}>
        Awesome
      </button>
      <button className="btn outline" onClick={onDouble} disabled={busy} aria-label="Watch Ad to Double Coins, times 2">
        Watch Ad to Double Coins (<span aria-hidden="true">🪙</span> x2)
      </button>
    </ModalShell>
  );
}
