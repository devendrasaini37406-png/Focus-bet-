import { useEffect, useRef } from 'react';

const FOCUSABLE = 'button:not([disabled]), [href], input, select, [tabindex]:not([tabindex="-1"])';

/** Accessible dialog: moves focus in, keeps Tab inside, and restores focus on close. */
export default function ModalShell({ children, label, alert = false }) {
  const ref = useRef(null);

  useEffect(() => {
    const card = ref.current;
    const previous = document.activeElement;
    const items = () => Array.from(card.querySelectorAll(FOCUSABLE));

    const first = card.querySelector('[data-autofocus]') || items()[0] || card;
    first.focus();

    const onKey = (e) => {
      if (e.key !== 'Tab') return;
      const list = items();
      if (!list.length) {
        e.preventDefault();
        return;
      }
      const head = list[0];
      const tail = list[list.length - 1];
      if (e.shiftKey && document.activeElement === head) {
        e.preventDefault();
        tail.focus();
      } else if (!e.shiftKey && document.activeElement === tail) {
        e.preventDefault();
        head.focus();
      }
    };
    card.addEventListener('keydown', onKey);
    return () => {
      card.removeEventListener('keydown', onKey);
      if (previous && previous.focus) previous.focus();
    };
  }, []);

  return (
    <div className="modal-backdrop">
      <div
        ref={ref}
        tabIndex={-1}
        className="modal-card"
        role={alert ? 'alertdialog' : 'dialog'}
        aria-modal="true"
        aria-label={label}
      >
        {children}
      </div>
    </div>
  );
}
