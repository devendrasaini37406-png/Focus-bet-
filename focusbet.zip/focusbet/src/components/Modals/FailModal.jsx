import { AlertTriangle } from '../Common/Icons';
import ModalShell from './ModalShell';
import { TIMER } from '../../config/appConfig';

const SECONDS = Math.round(TIMER.graceMs / 1000);

const REASONS = {
  background: ['Bet lost', 'You left the app during your focus session.'],
  lock: ['Bet lost', `Your screen stayed locked for more than ${SECONDS} seconds.`],
  notification: ['Bet lost', `You were away from the app for more than ${SECONDS} seconds.`],
  clock: ['Bet invalidated', 'A system clock change was detected during your focus session.'],
  killed: ['Bet lost', 'The app was closed during your focus session.'],
};

export default function FailModal({ reason, shieldSaved, onClose }) {
  const [title, text] = REASONS[reason] || REASONS.background;
  const outcome = shieldSaved
    ? 'Your Streak Freeze Shield protected your streak.'
    : 'You lost this bet and your streak was reset.';
  return (
    <ModalShell label={title} alert>
      <div className="modal-icon danger" aria-hidden="true">
        <AlertTriangle size={36} />
      </div>
      <h2 className="modal-title">{title}</h2>
      <p className="modal-text">
        {text} {outcome}
      </p>
      <p className="modal-note">Every focused minute counts. Ready for another go?</p>
      <button className="btn muted" onClick={onClose}>
        Try again
      </button>
    </ModalShell>
  );
}
