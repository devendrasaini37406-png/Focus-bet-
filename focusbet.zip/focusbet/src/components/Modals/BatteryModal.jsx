import { BatteryCharging } from '../Common/Icons';
import ModalShell from './ModalShell';
import { getAdStatus } from '../../services/ads';

export default function BatteryModal({ onClose }) {
  const ads = getAdStatus();
  return (
    <ModalShell label="Battery optimization">
      <div className="modal-icon accent round" aria-hidden="true">
        <BatteryCharging size={28} />
      </div>
      <h2 className="modal-title">Battery optimization</h2>
      <p className="modal-text">
        To ensure your bets are tracked perfectly in the background, please disable battery optimization for FocusBet
        in your phone settings.
      </p>
      <p className="modal-note" style={{ textAlign: 'left' }}>
        Ad status: {ads.mode}. Setup: {ads.init}. Banner: {ads.banner}. Rewarded: {ads.rewarded}.
      </p>
      <button className="btn primary" onClick={onClose}>
        Got it
      </button>
    </ModalShell>
  );
}
