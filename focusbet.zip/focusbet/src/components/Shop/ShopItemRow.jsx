import { Leaf, Palette, Shield } from '../Common/Icons';
import { ASSETS } from '../../config/assets';

const ICONS = { neon: Palette, zen: Leaf, shield: Shield };

export default function ShopItemRow({ item, owned, equipped, coins, onBuy, onToggle }) {
  const Icon = ICONS[item.id] || Shield;
  const canAfford = coins >= item.cost;

  let action;
  let info;
  if (owned) {
    if (item.kind === 'consumable') {
      action = (
        <button className="row-btn" disabled aria-label={`${item.name}, owned`}>
          Owned
        </button>
      );
      info = <span className="accent">Owned</span>;
    } else {
      action = (
        <button
          className="row-btn outline"
          onClick={() => onToggle(item.id)}
          aria-label={`${equipped ? 'Unequip' : 'Equip'} ${item.name}`}
        >
          {equipped ? 'Unequip' : 'Equip'}
        </button>
      );
      info = <span className="accent">{equipped ? 'Owned, equipped' : 'Owned'}</span>;
    }
  } else {
    action = (
      <button
        className="row-btn primary"
        disabled={!canAfford}
        onClick={() => onBuy(item)}
        aria-label={`Buy ${item.name} for ${item.cost} coins${canAfford ? '' : ', not enough coins'}`}
      >
        Buy
      </button>
    );
    info = canAfford ? (
      <span className="price">
        <img src={ASSETS.icons.coin} alt="" width="14" height="14" /> {item.cost} Coins
      </span>
    ) : (
      <span>
        <span className="warn">Not enough coins</span> <span className="muted-text">({item.cost})</span>
      </span>
    );
  }

  return (
    <div className="row">
      <div className="row-icon" aria-hidden="true">
        <Icon size={22} />
      </div>
      <div className="row-main">
        <div className="row-title">{item.name}</div>
        <div className="row-desc">{item.desc}</div>
        <div className="row-info">{info}</div>
      </div>
      {action}
    </div>
  );
}
