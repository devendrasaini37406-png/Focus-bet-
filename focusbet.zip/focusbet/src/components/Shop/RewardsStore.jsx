import { Loader2, WifiOff } from '../Common/Icons';
import DealCard from './DealCard';

export default function RewardsStore({ status, items, coins, redeemed, onRetry, onRedeem, onOpen }) {
  if (status === 'idle' || status === 'loading') {
    return (
      <div className="state-box" role="status" aria-busy="true">
        <Loader2 size={36} className="accent spin" aria-hidden="true" />
        <p>Loading latest deals...</p>
      </div>
    );
  }
  if (status === 'error') {
    return (
      <div className="state-box" role="alert">
        <WifiOff size={36} className="muted-text" aria-hidden="true" />
        <p className="state-msg">Connect to the internet to load latest exclusive deals!</p>
        <button className="row-btn primary wide" onClick={onRetry}>
          Retry
        </button>
      </div>
    );
  }
  if (items.length === 0) {
    return (
      <div className="state-box" role="status">
        <p>New deals are on the way. Check back soon!</p>
      </div>
    );
  }
  return (
    <div>
      {items.map((deal) => (
        <DealCard
          key={deal.id}
          deal={deal}
          coins={coins}
          unlocked={redeemed.includes(deal.id)}
          onRedeem={onRedeem}
          onOpen={onOpen}
        />
      ))}
    </div>
  );
}
