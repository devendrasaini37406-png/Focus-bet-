import { useEffect, useRef, useState } from 'react';
import { Browser } from '@capacitor/browser';
import { Check, Gift, ShoppingBag, X } from '../Common/Icons';
import ShopItemRow from './ShopItemRow';
import RewardsStore from './RewardsStore';
import { useStoreProducts } from '../../hooks/useStoreProducts';
import { IAP, SHOP_ITEMS } from '../../config/appConfig';
import { ASSETS } from '../../config/assets';

export default function ShopSheet({ open, state, actions, onClose, onRemoveAds, onToast }) {
  const [tab, setTab] = useState('items');
  const store = useStoreProducts(open && tab === 'deals');
  const closeRef = useRef(null);
  const returnFocus = useRef(null);

  // Focus moves into the sheet when it opens and back to the Shop button when it closes.
  useEffect(() => {
    if (open) {
      returnFocus.current = document.activeElement;
      const id = setTimeout(() => closeRef.current && closeRef.current.focus(), 50);
      return () => clearTimeout(id);
    }
    if (returnFocus.current && returnFocus.current.focus) returnFocus.current.focus();
    returnFocus.current = null;
    return undefined;
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const isOwned = (item) => (item.id === 'shield' ? state.shield > 0 : state.owned[item.id]);

  const redeem = (deal) => {
    if (actions.redeemDeal(deal)) onToast('Deal unlocked!');
  };
  const openDeal = (deal) => {
    if (!/^https:\/\//i.test(deal.affiliateUrl)) return;
    onToast('Opening deal...');
    Browser.open({ url: deal.affiliateUrl }).catch(() => onToast('Could not open the deal. Please try again.'));
  };

  return (
    <div className={`shop ${open ? 'open' : ''}`} aria-hidden={!open} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label="Shop">
        <div className="sheet-head">
          <h2>Shop</h2>
          <div className="sheet-head-right">
            <span className="sheet-balance">
              <img src={ASSETS.icons.coin} alt="" width="16" height="16" /> {state.coins} Coins
            </span>
            <button ref={closeRef} className="icon-btn small" aria-label="Close shop" onClick={onClose}>
              <X size={16} aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="tabs" role="tablist" aria-label="Shop sections">
          <button
            role="tab"
            id="tab-items"
            aria-selected={tab === 'items'}
            aria-controls="panel-shop"
            className={`tab ${tab === 'items' ? 'on' : ''}`}
            onClick={() => setTab('items')}
          >
            <ShoppingBag size={16} aria-hidden="true" /> Items
          </button>
          <button
            role="tab"
            id="tab-deals"
            aria-selected={tab === 'deals'}
            aria-controls="panel-shop"
            className={`tab ${tab === 'deals' ? 'on' : ''}`}
            onClick={() => setTab('deals')}
          >
            <Gift size={16} aria-hidden="true" /> Rewards Store
          </button>
        </div>

        <div className="sheet-body" role="tabpanel" id="panel-shop" aria-labelledby={`tab-${tab}`}>
          {tab === 'items' ? (
            <>
              {SHOP_ITEMS.map((item) => (
                <ShopItemRow
                  key={item.id}
                  item={item}
                  owned={isOwned(item)}
                  equipped={state.equip[item.id]}
                  coins={state.coins}
                  onBuy={actions.buyItem}
                  onToggle={actions.toggleEquip}
                />
              ))}
              <div className="iap">
                {state.adsRemoved ? (
                  <button className="row-btn wide" disabled>
                    <Check size={14} aria-hidden="true" /> Ads removed
                  </button>
                ) : (
                  <button className="row-btn outline wide" onClick={onRemoveAds}>
                    Remove Ads - {IAP.priceLabel}
                  </button>
                )}
              </div>
            </>
          ) : (
            <RewardsStore
              status={store.status}
              items={store.items}
              coins={state.coins}
              redeemed={state.redeemed}
              onRetry={store.reload}
              onRedeem={redeem}
              onOpen={openDeal}
            />
          )}
        </div>
      </div>
    </div>
  );
}
