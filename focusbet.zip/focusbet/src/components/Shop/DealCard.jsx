import { ASSETS } from '../../config/assets';
import { formatRupee } from '../../utils/format';

export default function DealCard({ deal, coins, unlocked, onRedeem, onOpen }) {
  const canAfford = coins >= deal.coinsRequired;
  return (
    <div className="row">
      <img className="thumb" src={deal.imageUrl} alt="" width="56" height="56" />
      <div className="row-main">
        <div className="row-title">{deal.title}</div>
        <div className="row-prices">
          <s className="muted-text" aria-label={`was ${formatRupee(deal.originalPrice)}`}>
            {formatRupee(deal.originalPrice)}
          </s>{' '}
          <strong aria-label={`now ${formatRupee(deal.dealPrice)}`}>{formatRupee(deal.dealPrice)}</strong>
        </div>
        <div className="row-info">
          {unlocked ? (
            <span className="accent">Unlocked</span>
          ) : canAfford ? (
            <span className="price">
              <img src={ASSETS.icons.coin} alt="" width="14" height="14" /> {deal.coinsRequired} Coins
            </span>
          ) : (
            <span>
              <span className="warn">Not enough coins</span> <span className="muted-text">({deal.coinsRequired})</span>
            </span>
          )}
        </div>
      </div>
      {unlocked ? (
        <button className="row-btn outline" onClick={() => onOpen(deal)} aria-label={`Open deal: ${deal.title}`}>
          Open deal
        </button>
      ) : (
        <button
          className="row-btn primary"
          disabled={!canAfford}
          onClick={() => onRedeem(deal)}
          aria-label={`Redeem ${deal.title} for ${deal.coinsRequired} coins${canAfford ? '' : ', not enough coins'}`}
        >
          Redeem
        </button>
      )}
    </div>
  );
}
