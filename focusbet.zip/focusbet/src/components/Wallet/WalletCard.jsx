import { ASSETS } from '../../config/assets';
import { WITHDRAWAL } from '../../config/appConfig';
import { canWithdraw, coinsNeeded, coinsToRupees, formatCoins } from '../../utils/withdraw';

export default function WalletCard({ coins, onWithdraw }) {
  const unlocked = canWithdraw(coins);
  const label = unlocked
    ? 'Withdraw Cash'
    : `Withdraw Cash, locked. ${formatCoins(coinsNeeded(coins))} more coins needed`;
  return (
    <section className="wallet-card" aria-label="Wallet">
      <div className="wallet-row">
        <div className="wallet-main">
          <span className="wallet">
            <img src={ASSETS.icons.coin} alt="" width="18" height="18" />
            {formatCoins(coins)} Coins
          </span>
          <span className="wallet-cash" aria-live="polite">
            ≈ {coinsToRupees(coins)} cash value
          </span>
        </div>
        {/* Stays clickable when locked so the player can see how far away the goal is. */}
        <button className={`withdraw-btn ${unlocked ? '' : 'locked'}`} aria-label={label} onClick={onWithdraw}>
          Withdraw Cash
        </button>
      </div>
      {!unlocked && (
        <div
          className="wallet-progress"
          role="progressbar"
          aria-label="Progress to your first cash withdrawal"
          aria-valuemin={0}
          aria-valuemax={WITHDRAWAL.minCoins}
          aria-valuenow={Math.min(coins, WITHDRAWAL.minCoins)}
        >
          <div style={{ width: `${Math.min(100, (coins / WITHDRAWAL.minCoins) * 100)}%` }} />
        </div>
      )}
    </section>
  );
}
