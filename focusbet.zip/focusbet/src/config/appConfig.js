/* ==========================================================================
 *  FOCUSBET CONFIG  -  the one file to edit before you ship
 * ==========================================================================
 *  1. ADMOB: replace every 'PASTE_..._HERE' below with your production IDs
 *     (or set the matching VITE_ variables in .env, which take priority).
 *  2. Flip ADMOB.useTestAds to false (or VITE_USE_TEST_ADS=false) for release.
 *  3. The App ID must ALSO go into the native projects. See README.md ->
 *     "AdMob IDs" and the files in /native-snippets.
 *
 *  While useTestAds is true, or while any production ID is still a PASTE_
 *  placeholder, the app uses Google's official test ads. You can't be
 *  banned for tapping test ads, so leave them on during development.
 * ======================================================================== */

const env = import.meta.env;

// Release builds: set this to false (or VITE_USE_TEST_ADS=false) once the production IDs below are filled in.
const USE_TEST_ADS_DEFAULT = false;

export const ADMOB = {
  useTestAds: env.VITE_USE_TEST_ADS ? env.VITE_USE_TEST_ADS !== 'false' : USE_TEST_ADS_DEFAULT,

  production: {
    android: {
      appId: env.VITE_ADMOB_ANDROID_APP_ID || 'ca-app-pub-2429673781810348~5268715412', // ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY
      bannerAdUnitId: env.VITE_ADMOB_ANDROID_BANNER_ID || 'ca-app-pub-2429673781810348/8653638682', // ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY
      rewardedAdUnitId: env.VITE_ADMOB_ANDROID_REWARDED_ID || 'ca-app-pub-2429673781810348/1888919781',
    },
    ios: {
      appId: env.VITE_ADMOB_IOS_APP_ID || 'PASTE_IOS_ADMOB_APP_ID_HERE',
      bannerAdUnitId: env.VITE_ADMOB_IOS_BANNER_ID || 'PASTE_IOS_BANNER_AD_UNIT_ID_HERE',
      rewardedAdUnitId: env.VITE_ADMOB_IOS_REWARDED_ID || 'PASTE_IOS_REWARDED_AD_UNIT_ID_HERE',
    },
  },

  // Google's public sample IDs. Safe to ship in development builds.
  test: {
    android: {
      appId: 'ca-app-pub-3940256099942544~3347511713',
      bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
      rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
    },
    ios: {
      appId: 'ca-app-pub-3940256099942544~1458002511',
      bannerAdUnitId: 'ca-app-pub-3940256099942544/2934735716',
      rewardedAdUnitId: 'ca-app-pub-3940256099942544/1712485313',
    },
  },
};

/* ---------- App, economy, timer ---------- */
export const APP = {
  name: 'FocusBet',
  storageKey: 'focusbet_v2',
};

export const ECONOMY = {
  startingCoins: 150,
  betCost: 10, // lost on a failed bet
  coinsPerMinute: 2, // default rate: coins per focused minute (5 min = 10, 30 min = 60)
  // Longer sessions are rewarded slightly less per minute. Any length listed here overrides the default rate.
  rewardByMinutes: { 45: 75, 60: 90 },
};

export const TIMER = {
  presetsMin: [5, 10, 15, 30, 45, 60],
  defaultMin: 25,
  graceMs: 3000, // screen lock / notification grace period
  clockDriftMs: 2000, // allowed gap between phone clock and monotonic clock
  simulatedAdSeconds: 5, // web preview only; native uses the real AdMob video
};

/* ---------- Shop ---------- */
export const SHOP_ITEMS = [
  { id: 'neon', name: 'Neon Cyberpunk Theme', desc: 'Magenta glow on a midnight screen', cost: 200, kind: 'equip' },
  { id: 'zen', name: 'Zen Forest Ambient Sound', desc: 'Calm forest sound while you focus', cost: 500, kind: 'equip' },
  { id: 'shield', name: 'Streak Freeze Shield', desc: 'Protects your streak once if you fail', cost: 1000, kind: 'consumable' },
];

export const IAP = {
  removeAdsProductId: 'remove_ads', // must match the product ID in Play Console / App Store Connect
  priceLabel: '₹99',
  // Web preview and debug builds simulate the payment. Release builds REFUSE to grant it
  // until a real billing provider is wired into src/services/billing.js and this is set to false.
  useMock: !env.PROD,
};

/* ---------- Rewards Store data source ---------- */
export const REWARDS_API = {
  // PASTE YOUR LIVE LINK HERE (or set VITE_PRODUCTS_URL in .env). Either of these works:
  //   - Google Sheet "Publish to web" CSV link: https://docs.google.com/spreadsheets/d/e/.../pub?output=csv
  //   - SheetDB link:                           https://sheetdb.io/api/v1/xxxxxxxx
  url: env.VITE_PRODUCTS_URL || 'https://docs.google.com/spreadsheets/d/1HTPRljqYTDPQdB3_yqszeA-zpyt3qStDjeNjwlxnzVg/export?format=csv&gid=1773412860',
  timeoutMs: 10000, // give up after 10s and show the Retry screen
};

/* ---------- Cash withdrawal ---------- */
export const WITHDRAWAL = {
  coinsPerRupee: 100, // 100 coins = Rs 1
  minCoins: 1000, // balance needed before the Withdraw Cash form unlocks
  coinCost: 1000, // coins deducted for each request
  amountLabel: '₹10', // what one request pays out
  // Apps Script web app URL (see google-apps-script/Code.gs). Never use a public/published sheet link here.
  url: env.VITE_WITHDRAW_URL || 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE',
  timeoutMs: 10000,
  retryMs: 30000, // unsent requests are retried this often while the app is open
};
