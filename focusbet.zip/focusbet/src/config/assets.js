/* Every image and sound the app uses is listed here.
 * To go to production, drop your files into /public/assets (same names)
 * or change the paths below. Nothing else in the code references a file path. */
const base = import.meta.env.BASE_URL;
const a = (path) => `${base}assets/${path}`;

export const ASSETS = {
  icons: {
    coin: a('icons/coin.svg'),
    logo: a('icons/logo.svg'),
  },
  sounds: {
    zenForest: a('sounds/zen-forest.wav'),
    timerEnd: a('sounds/timer-end.wav'), // rings when a bet is won; swap for your own file
  },
  products: {
    earbuds: a('products/earbuds.svg'),
    lamp: a('products/lamp.svg'),
    planner: a('products/planner.svg'),
    bottle: a('products/bottle.svg'),
  },
};
