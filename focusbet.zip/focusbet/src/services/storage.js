import { Preferences } from '@capacitor/preferences';

// On device this uses native storage (survives app updates and cache clears).
// In the browser the plugin falls back to localStorage automatically.
export async function loadJson(key, fallback) {
  try {
    const { value } = await Preferences.get({ key });
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

// Writes run strictly one after another, so an older save can never land after a newer one.
let writes = Promise.resolve();

export function saveJson(key, data) {
  const value = JSON.stringify(data); // snapshot now, not when the write actually runs
  writes = writes.then(() => Preferences.set({ key, value })).catch(() => {
    /* storage unavailable: keep running in memory */
  });
  return writes;
}

export function removeKey(key) {
  writes = writes.then(() => Preferences.remove({ key })).catch(() => {});
  return writes;
}
