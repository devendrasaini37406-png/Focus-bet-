import { Capacitor } from '@capacitor/core';
import { ADMOB } from '../config/appConfig';

export const isNative = Capacitor.isNativePlatform();

const platformKey = Capacitor.getPlatform() === 'ios' ? 'ios' : 'android';
const APP_ID = /^ca-app-pub-\d{16}~\d{10}$/;
const UNIT_ID = /^ca-app-pub-\d{16}\/\d{10}$/;

/** Production IDs when they are valid and test ads are off, otherwise Google's test IDs. */
function resolveIds() {
  const prod = ADMOB.production[platformKey];
  const prodOk =
    APP_ID.test(String(prod.appId).trim()) &&
    UNIT_ID.test(String(prod.bannerAdUnitId).trim()) &&
    UNIT_ID.test(String(prod.rewardedAdUnitId).trim());
  if (!ADMOB.useTestAds && !prodOk) {
    console.warn('[ads] Production AdMob IDs are missing or invalid. Falling back to Google test ads.');
  }
  const useTest = ADMOB.useTestAds || !prodOk;
  const ids = useTest ? ADMOB.test[platformKey] : prod;
  return {
    isTesting: useTest,
    bannerAdUnitId: String(ids.bannerAdUnitId).trim(),
    rewardedAdUnitId: String(ids.rewardedAdUnitId).trim(),
  };
}

let plugin = null;
const loadPlugin = () => plugin || (plugin = import('@capacitor-community/admob'));

// Banner calls run one at a time so a quick show/hide can never leave them out of order.
let chain = Promise.resolve();
const queue = (fn) => (chain = chain.then(fn).catch((e) => console.warn('[ads]', e && e.message ? e.message : e)));

let ready = false;
let bannerOn = false;

const ERROR_TEXT = {
  0: 'internal error',
  1: 'invalid request, check the ad unit ID and that it matches the ad type',
  2: 'network error',
  3: 'no ad available yet (common for new ad units and apps)',
};
const status = { init: 'not started', banner: 'not requested', rewarded: 'not requested' };
const describe = (e) => {
  const code = e && e.code !== undefined ? e.code : '?';
  return `failed (code ${code}: ${ERROR_TEXT[code] || (e && e.message) || 'unknown'})`;
};

/** Plain-text ad state for the Settings screen, so a tester can see why ads are missing. */
export function getAdStatus() {
  if (!isNative) return { mode: 'browser preview', ...status, init: 'ads run on the phone only' };
  return { mode: resolveIds().isTesting ? 'test ads' : 'live ads', ...status };
}

export function initAds() {
  if (!isNative) return Promise.resolve();
  return queue(async () => {
    if (ready) return;
    try {
      const { AdMob, BannerAdPluginEvents } = await loadPlugin();
      await AdMob.initialize({ initializeForTesting: resolveIds().isTesting });
      AdMob.addListener(BannerAdPluginEvents.Loaded, () => { status.banner = 'loaded'; });
      AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (e) => { status.banner = describe(e); });
      ready = true;
      status.init = 'ready';
    } catch (e) {
      status.init = `failed (${e && e.message ? e.message : e})`;
      throw e;
    }
  });
}

export function showBanner() {
  if (!isNative) return Promise.resolve();
  return queue(async () => {
    if (!ready || bannerOn) return;
    const { AdMob, BannerAdSize, BannerAdPosition } = await loadPlugin();
    const ids = resolveIds();
    status.banner = 'requested';
    await AdMob.showBanner({
      adId: ids.bannerAdUnitId,
      adSize: BannerAdSize.BANNER, // 320x50, matches the reserved 50px slot
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: ids.isTesting,
    });
    bannerOn = true;
  });
}

export function hideBanner() {
  if (!isNative) return Promise.resolve();
  return queue(async () => {
    if (!bannerOn) return;
    const { AdMob } = await loadPlugin();
    await AdMob.removeBanner();
    bannerOn = false;
  });
}

const REWARDED_TIMEOUT_MS = 120000;

/** Resolves true only when the viewer earned the reward. Never rejects. */
export async function showRewardedAd() {
  if (!isNative) return false;
  const handles = [];
  try {
    const { AdMob, RewardAdPluginEvents } = await loadPlugin();
    const ids = resolveIds();
    let rewarded = false;
    let finish;
    const outcome = new Promise((resolve) => { finish = resolve; });

    status.rewarded = 'requested';
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Rewarded, () => { rewarded = true; status.rewarded = 'reward earned'; }));
    // Small delay: on some devices "dismissed" can arrive just before "rewarded".
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => setTimeout(() => finish(rewarded), 300)));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToLoad, (e) => { status.rewarded = describe(e); finish(false); }));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToShow, (e) => { status.rewarded = describe(e); finish(false); }));

    try {
      await AdMob.prepareRewardVideoAd({ adId: ids.rewardedAdUnitId, isTesting: ids.isTesting });
      await AdMob.showRewardVideoAd();
    } catch (e) {
      status.rewarded = describe(e);
      finish(false);
    }
    const timeout = new Promise((resolve) => setTimeout(() => resolve(false), REWARDED_TIMEOUT_MS));
    return await Promise.race([outcome, timeout]);
  } catch {
    return false;
  } finally {
    handles.forEach((h) => h.remove());
  }
}
