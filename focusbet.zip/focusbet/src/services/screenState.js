import { Capacitor, registerPlugin } from '@capacitor/core';

/* Optional native plugin. A web view cannot tell "screen locked" from "app
 * minimized", so the 3-second lock grace period needs a native screen-off
 * signal. See README.md -> "Screen lock grace period" and
 * native-snippets/android/ScreenStatePlugin.java.
 * Until the plugin is added, every app exit is treated as a strict fail. */
const ScreenState = registerPlugin('ScreenState');

export function listenScreenOff(callback) {
  if (!Capacitor.isNativePlatform()) return () => {};
  let handle = null;
  let disposed = false;
  ScreenState.addListener('screenOff', callback)
    .then((h) => {
      if (disposed) h.remove();
      else handle = h;
    })
    .catch(() => {
      /* plugin not installed */
    });
  return () => {
    disposed = true;
    if (handle) handle.remove();
  };
}
