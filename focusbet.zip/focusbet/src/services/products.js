import { REWARDS_API } from '../config/appConfig';
import { ASSETS } from '../config/assets';
import { withTimeout } from '../utils/net';

/* Loads the Rewards Store products from a live URL:
 *   - a Google Sheet published as CSV  (File > Share > Publish to web > CSV), or
 *   - a SheetDB / any JSON API that returns an array of objects.
 * The URL lives in REWARDS_API.url (src/config/appConfig.js) or VITE_PRODUCTS_URL in .env.
 * Columns are matched by NAME, so their order in the sheet doesn't matter. */

const FIELDS = ['id', 'title', 'imageUrl', 'coinsRequired', 'originalPrice', 'dealPrice', 'affiliateUrl'];
const REQUIRED = ['id', 'title', 'coinsRequired', 'originalPrice', 'dealPrice', 'affiliateUrl'];

// "Coins Required", "coins_required" and "coinsRequired" are all the same column.
const keyOf = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
const LOOKUP = Object.fromEntries(FIELDS.map((f) => [keyOf(f), f]));

/** Small CSV parser: handles quotes, commas and line breaks inside quotes, CRLF, and a BOM. */
function parseCsv(text) {
  const src = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i];
    if (quoted) {
      if (c === '"') {
        if (src[i + 1] === '"') { cell += '"'; i += 1; } else quoted = false;
      } else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i += 1;
      row.push(cell); cell = '';
      rows.push(row); row = [];
    } else cell += c;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((x) => x.trim() !== ''));
}

/** Renames headers to our field names and rejects sheets that lack a required column. */
function toObjects(headerCells, bodyRows) {
  const fields = headerCells.map((h) => LOOKUP[keyOf(h)] || null);
  const missing = REQUIRED.filter((f) => !fields.includes(f));
  if (missing.length) throw new Error(`missing columns: ${missing.join(', ')}`);
  return bodyRows.map((cells) => {
    const obj = {};
    fields.forEach((f, i) => { if (f) obj[f] = cells[i]; });
    return obj;
  });
}

function parseResponse(text) {
  const t = text.trim();
  if (!t || t.startsWith('<')) throw new Error('not data (is the sheet published?)'); // HTML sign-in page
  if (t.startsWith('[') || t.startsWith('{')) {
    const json = JSON.parse(t);
    if (json && json.error) throw new Error(String(json.error));
    const list = Array.isArray(json) ? json : json.data;
    if (!Array.isArray(list)) throw new Error('unexpected JSON shape');
    if (list.length === 0) return [];
    const headers = Object.keys(list[0]);
    return toObjects(headers, list.map((item) => headers.map((h) => item[h])));
  }
  const [header, ...body] = parseCsv(t);
  return header ? toObjects(header, body) : [];
}

const toNumber = (v) => Number(String(v ?? '').replace(/[₹,\s]|rs\.?/gi, ''));

function toProduct(r) {
  const image = String(r.imageUrl ?? '').trim();
  return {
    id: String(r.id ?? '').trim(),
    title: String(r.title ?? '').trim(),
    // Only https images load inside the app; anything else falls back to the coin icon.
    imageUrl: /^https:\/\//i.test(image) ? image : ASSETS.icons.coin,
    coinsRequired: Math.round(toNumber(r.coinsRequired)),
    originalPrice: toNumber(r.originalPrice),
    dealPrice: toNumber(r.dealPrice),
    affiliateUrl: String(r.affiliateUrl ?? '').trim(),
  };
}

// Rows come from an external sheet, so treat them as untrusted: skip anything malformed or not https.
const isValid = (p) =>
  p.id && p.title &&
  Number.isFinite(p.coinsRequired) && p.coinsRequired >= 0 &&
  Number.isFinite(p.originalPrice) && p.originalPrice >= 0 &&
  Number.isFinite(p.dealPrice) && p.dealPrice >= 0 &&
  /^https:\/\//i.test(p.affiliateUrl);

/**
 * Resolves to an array of valid products. Rejects (offline, timeout, bad URL, bad sheet),
 * which makes the Rewards Store show "Connect to the internet..." with a Retry button.
 */
export async function fetchStoreProducts(url = REWARDS_API.url) {
  const target = String(url || '').trim();
  if (!/^https:\/\//i.test(target)) {
    console.error('[products] No data URL set. Paste your Google Sheet CSV or SheetDB link into REWARDS_API.url.');
    throw new Error('not-configured');
  }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new Error('offline');

  const controller = new AbortController();
  const response = await withTimeout(
    fetch(target, { signal: controller.signal, cache: 'no-store' }),
    REWARDS_API.timeoutMs,
    () => controller.abort(),
  );
  if (!response.ok) throw new Error(`http ${response.status}`);

  const text = await withTimeout(response.text(), REWARDS_API.timeoutMs, () => controller.abort());
  const seen = new Set();
  return parseResponse(text)
    .map(toProduct)
    .filter(isValid)
    .filter((p) => (seen.has(p.id) ? false : seen.add(p.id)));
}
