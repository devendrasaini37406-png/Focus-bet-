import { IAP } from '../config/appConfig';

/**
 * Resolves { success: true, orderId } or { success: false }. Never rejects.
 *
 * Wire a real provider in here (RevenueCat, cordova-plugin-purchase, Google Play Billing...)
 * and then set IAP.useMock to false in src/config/appConfig.js.
 * Until then, release builds refuse to grant the purchase so nobody gets ads removed for free.
 */
export async function purchaseRemoveAds() {
  try {
    if (!IAP.useMock) {
      console.warn('[billing] No billing provider is configured yet. See src/services/billing.js.');
      return { success: false, error: 'not-configured' };
    }
    await new Promise((resolve) => setTimeout(resolve, 1600));
    return { success: true, orderId: `MOCK${String(Date.now()).slice(-8)}` };
  } catch (e) {
    return { success: false, error: String(e) };
  }
}
