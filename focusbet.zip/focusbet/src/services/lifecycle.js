import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { listenScreenOff } from './screenState';

/**
 * Normalises app visibility into three callbacks.
 *   onBackground()      app left the screen (home, app switcher). Strict fail.
 *   onInterrupt(kind)   short interruption: 'lock' or 'notification'. Grace period.
 *   onForeground()      app is back in front.
 * Returns an unsubscribe function (safe to call even before the native listener is ready).
 */
export function watchLifecycle({ onBackground, onInterrupt, onForeground }) {
  const cleanups = [];
  let disposed = false;

  if (Capacitor.isNativePlatform()) {
    let lastScreenOff = 0;

    App.addListener('appStateChange', ({ isActive }) => {
      if (isActive) onForeground();
      // If the screen-off signal just fired, the lock grace logic already owns this event.
      else if (Date.now() - lastScreenOff > 1500) onBackground();
    }).then((handle) => {
      if (disposed) handle.remove();
      else cleanups.push(() => handle.remove());
    });

    cleanups.push(
      listenScreenOff(() => {
        lastScreenOff = Date.now();
        onInterrupt('lock');
      }),
    );

    // Pulling down the notification shade blurs the web view while the app stays visible.
    const onBlur = () => document.visibilityState === 'visible' && onInterrupt('notification');
    const onFocus = () => onForeground();
    window.addEventListener('blur', onBlur);
    window.addEventListener('focus', onFocus);
    cleanups.push(() => {
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('focus', onFocus);
    });
  } else {
    // Browser preview: any hidden tab counts as leaving the app.
    const onVisibility = () => (document.hidden ? onBackground() : onForeground());
    document.addEventListener('visibilitychange', onVisibility);
    cleanups.push(() => document.removeEventListener('visibilitychange', onVisibility));
  }

  return () => {
    disposed = true;
    cleanups.forEach((fn) => fn());
  };
}
