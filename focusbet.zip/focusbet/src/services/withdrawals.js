import { WITHDRAWAL } from '../config/appConfig';
import { withTimeout } from '../utils/net';

export const isWithdrawalConfigured = () => /^https:\/\//i.test(String(WITHDRAWAL.url || '').trim());

async function send(req) {
  const controller = new AbortController();
  const res = await withTimeout(
    fetch(WITHDRAWAL.url.trim(), {
      method: 'POST',
      // text/plain keeps this a "simple" request, so Apps Script needs no CORS preflight.
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ id: req.id, upiId: req.upiId, amount: WITHDRAWAL.amountLabel, status: 'Pending' }),
      signal: controller.signal,
      redirect: 'follow',
    }),
    WITHDRAWAL.timeoutMs,
    () => controller.abort(),
  );
  if (!res.ok) throw new Error(`http ${res.status}`);
  const json = await withTimeout(res.json(), WITHDRAWAL.timeoutMs);
  if (json && json.ok === true) return;
  // The server refuses requests that fail its own checks (only possible if the app was tampered with).
  // Retrying would never help, so treat it as finished instead of looping forever.
  if (json && json.error === 'invalid') return;
  throw new Error((json && json.error) || 'rejected');
}

let flushing = false;

/**
 * Sends queued requests one by one, oldest first, and calls onSent(id) after each success.
 * Stops at the first failure (offline, timeout, server error) so the rest are retried later.
 * Safe to call repeatedly: overlapping calls are ignored, and the server ignores duplicate ids.
 */
export async function flushWithdrawals(list, onSent) {
  if (flushing || !isWithdrawalConfigured()) return 0;
  flushing = true;
  let sent = 0;
  try {
    for (const req of list.filter((w) => !w.sent)) {
      if (typeof navigator !== 'undefined' && navigator.onLine === false) break;
      try {
        await send(req);
      } catch (e) {
        console.warn('[withdrawals] will retry:', e && e.message ? e.message : e);
        break;
      }
      onSent(req.id);
      sent += 1;
    }
  } finally {
    flushing = false;
  }
  return sent;
}
