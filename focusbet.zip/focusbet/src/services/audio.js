let el = null;

export function playAmbient(src) {
  stopAmbient();
  el = new Audio(src);
  el.loop = true;
  el.volume = 0.5;
  el.play().catch(() => {
    /* autoplay blocked or file missing: stay silent */
  });
}

export function stopAmbient() {
  if (el) {
    el.pause();
    el = null;
  }
}

let chime = null;

/** Rings (and vibrates) when the countdown finishes, so the player notices even without looking. */
export function playChime(src) {
  try {
    if (!chime) chime = new Audio(src);
    chime.pause();
    chime.currentTime = 0;
    chime.volume = 1;
    chime.play().catch(() => {
      /* sound blocked or file missing: the vibration below still alerts the player */
    });
  } catch {
    /* no audio support */
  }
  if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate([400, 200, 400, 200, 600]);
}

export function stopChime() {
  if (chime) {
    chime.pause();
    chime.currentTime = 0;
  }
}
