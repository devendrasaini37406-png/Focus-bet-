// Copies the AdMob App ID from src/config/appConfig.js (and .env overrides) into the native projects.
// Run after `npx cap add android|ios` and `npx cap sync` (the npm scripts already do this).
import fs from 'node:fs';

const config = fs.readFileSync('src/config/appConfig.js', 'utf8');
const env = {};
if (fs.existsSync('.env')) {
  for (const line of fs.readFileSync('.env', 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const TEST = {
  android: 'ca-app-pub-3940256099942544~3347511713',
  ios: 'ca-app-pub-3940256099942544~1458002511',
};
const validApp = (v) => /^ca-app-pub-\d{16}~\d{10}$/.test((v || '').trim());

const defaultFlag = /USE_TEST_ADS_DEFAULT\s*=\s*(true|false)/.exec(config);
const useTest = env.VITE_USE_TEST_ADS ? env.VITE_USE_TEST_ADS !== 'false' : !defaultFlag || defaultFlag[1] === 'true';

function productionAppId(platform) {
  const envKey = platform === 'ios' ? 'VITE_ADMOB_IOS_APP_ID' : 'VITE_ADMOB_ANDROID_APP_ID';
  if (env[envKey]) return env[envKey];
  const block = new RegExp(`${platform}:\\s*\\{\\s*appId:[^|]*\\|\\|\\s*'([^']*)'`).exec(config);
  return block ? block[1] : '';
}
const pick = (platform) => {
  const prod = productionAppId(platform);
  if (!useTest && !validApp(prod)) {
    console.warn(`[admob:sync] ${platform}: production App ID missing or invalid, using the Google TEST App ID.`);
  }
  const usable = !useTest && validApp(prod);
  return { id: usable ? prod.trim() : TEST[platform], test: !usable };
};

const manifest = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(manifest)) {
  const { id, test } = pick('android');
  let xml = fs.readFileSync(manifest, 'utf8');
  const tag = `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${id}" />`;
  const re = /<meta-data\s+android:name="com\.google\.android\.gms\.ads\.APPLICATION_ID"[^>]*\/>/;
  xml = re.test(xml) ? xml.replace(re, tag) : xml.replace('</application>', `    ${tag}\n    </application>`);
  if (!xml.includes('com.google.android.gms.permission.AD_ID')) {
    xml = xml.replace('</manifest>', '    <uses-permission android:name="com.google.android.gms.permission.AD_ID" />\n</manifest>');
  }
  fs.writeFileSync(manifest, xml);
  console.log('Android AdMob App ID set:', id, test ? '(test)' : '(production)');
} else {
  console.log('Android project not found, skipping. Run: npx cap add android');
}

const plist = 'ios/App/App/Info.plist';
if (fs.existsSync(plist)) {
  const { id, test } = pick('ios');
  let p = fs.readFileSync(plist, 'utf8');
  const block = `<key>GADApplicationIdentifier</key>\n\t<string>${id}</string>`;
  const re = /<key>GADApplicationIdentifier<\/key>\s*<string>[^<]*<\/string>/;
  if (re.test(p)) p = p.replace(re, block);
  else {
    const i = p.lastIndexOf('</dict>');
    p = p.slice(0, i) + `\t${block}\n` + p.slice(i);
  }
  fs.writeFileSync(plist, p);
  console.log('iOS AdMob App ID set:', id, test ? '(test)' : '(production)');
} else {
  console.log('iOS project not found, skipping. Run: npx cap add ios');
}
