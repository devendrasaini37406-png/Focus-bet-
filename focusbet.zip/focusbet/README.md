# FocusBet

React + Vite app, packaged for Android (APK/AAB) and iOS with Capacitor.

```
src/
  config/appConfig.js    <- AdMob IDs, economy, timer, shop, IAP, deals sheet URL (edit this)
  config/assets.js       <- every image/sound path (swap files in public/assets)
  components/            Header, Timer, Modals, Shop, Ads, Payment, Common
  hooks/                 useFocusTimer, useGameState, useStoreProducts, useToast
  services/              ads, billing, lifecycle, screenState, storage, audio, products
  utils/                 format, time
native-snippets/android/ ScreenStatePlugin.java, MainActivity.java (lock-screen grace period)
scripts/apply-admob-ids.mjs   copies the AdMob App ID into AndroidManifest.xml / Info.plist
public/assets/           placeholder coin, logo, product images, zen-forest.wav
```

## 1. Get the code

```bash
git clone <your-repo-url> focusbet     # or unzip focusbet.zip
cd focusbet
```

## 2. Install the tools (once)

| Tool | Version | Notes |
|------|---------|-------|
| Node.js | 20 or newer | `node -v` |
| JDK | 21 | `java -version` (Capacitor 7 needs 21) |
| Android Studio | current | installs the Android SDK; set `ANDROID_HOME` |

## No Android Studio? Build the APK on GitHub

Push this project to a GitHub repository, open the **Actions** tab, choose **Build Android APK** > **Run workflow**.
After a few minutes download `focusbet-debug-apk` from the run page and install the `.apk` on your phone.
(Debug builds use Google test ads. For the Play Store build follow section 5.)

## 3. Build a debug APK (to test on a phone)

```bash
npm install
npx cap add android            # first time only, creates /android
npm run android:debug-apk      # build web app, sync, patch AdMob ID, run Gradle
```

The file is `android/app/build/outputs/apk/debug/app-debug.apk`. Install it:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

(or copy the file to the phone and open it; allow "install unknown apps").
On Windows use `gradlew.bat` in place of `./gradlew` if the npm script fails.

## 4. Before the real release

1. **App identity.** Set `appId` (for example `com.yourcompany.focusbet`) in `capacitor.config.json` *before* `npx cap add android`.
   If you already added Android, also change `applicationId` in `android/app/build.gradle`.
2. **AdMob IDs.** Open `src/config/appConfig.js` (or copy `.env.example` to `.env`) and paste your Android App ID,
   Banner Ad Unit ID and Rewarded Ad Unit ID, then set `USE_TEST_ADS_DEFAULT = false` (or `VITE_USE_TEST_ADS=false`).
   Run `npm run admob:sync` (the npm scripts already do). Invalid or empty IDs automatically fall back to Google's
   test ads, so a mistake can't ship broken ads. **Never click your own live ads.**
3. **Billing.** `IAP.useMock` is `true` in dev and `false` in release builds. A release build refuses the
   "Remove Ads" purchase until a real provider is wired into `src/services/billing.js` (Google Play Billing via RevenueCat,
   `cordova-plugin-purchase`, etc.). Create the product `remove_ads` in Play Console first.
4. **Assets.** Replace the placeholders in `public/assets` (same file names): `icons/coin.svg`, `icons/logo.svg`,
   `sounds/zen-forest.wav`, `products/*.svg`. Or edit the paths in `src/config/assets.js`.
   App icon and splash: put `assets/icon.png` (1024x1024) and `assets/splash.png` (2732x2732) in an `assets/` folder, then
   `npx @capacitor/assets generate --android --splashBackgroundColor "#1B2025"` (this also colours the phone's own launch screen to match the in-app opening animation).
5. **Deals sheet (live data).** Create a Google Sheet with the columns
   `id, title, imageUrl, coinsRequired, originalPrice, dealPrice, affiliateUrl` (one product per row), then
   File > Share > Publish to web > choose the Deals tab and **Comma-separated values (.csv)** > Publish.
   Paste the link into `REWARDS_API.url` in `src/config/appConfig.js` (or `VITE_PRODUCTS_URL` in `.env`).
   A SheetDB link (JSON) works too. Edit the sheet any time; the app picks changes up on the next load of the
   Rewards Store (Google can take a few minutes to refresh the published CSV). Rows with a missing field, a bad number
   or a non-https affiliate link are skipped. If the link is wrong, the phone is offline, or the request takes more than
   10 seconds, the store shows the Retry screen. If you ever see CORS errors on a device, add
   `"plugins": { "CapacitorHttp": { "enabled": true } }` to `capacitor.config.json`.
6. **Screen lock grace period (Android).** Copy `native-snippets/android/ScreenStatePlugin.java` and
   `MainActivity.java` into `android/app/src/main/java/<your/package>/`, and change the `package` line to match.
   Without it, locking the screen counts as leaving the app (strict fail).
7. **Play Console.** Fill in the Data safety form (AdMob collects the advertising ID), content rating, and disclose
   affiliate links in the store listing.

## Cash withdrawal (100 coins = ₹1)

* **Rules** live in `WITHDRAWAL` in `src/config/appConfig.js`: unlocks at 1,000 coins, each request deducts exactly 1,000 coins
  and pays ₹10. Below 1,000 coins the player sees how many coins are still missing.
* **The coin deduction and the request are saved together on the phone**, so a request can never be lost. If the phone is
  offline, the request waits in a queue and is sent automatically when the connection returns.
* **Recording requests in a Google Sheet** (the sheet must stay PRIVATE, it holds UPI IDs):
  1. Open the private sheet `FocusBet Withdrawals` (tab `Withdrawals`, columns `Timestamp, UPI ID, Amount, Status, Request ID`).
  2. Extensions > Apps Script, paste `google-apps-script/Code.gs`, save.
  3. Deploy > New deployment > Web app. Execute as **Me**, access **Anyone**. Copy the `/exec` URL.
  4. Paste it into `WITHDRAWAL.url` (or `VITE_WITHDRAW_URL` in `.env`) and rebuild.
* **Paying out** is manual: check each `Pending` row, send the money, then change Status to `Paid` or `Rejected`.
* Release builds refuse to open the form until `WITHDRAWAL.url` is set, so coins are never taken for a request that can't be delivered.
* The server ignores duplicate request IDs and always writes `₹10`, whatever the app sends.

## 5. Build the signed release (APK and AAB)

Create a signing key once and **back it up** (lose it and you cannot update the app):

```bash
keytool -genkey -v -keystore focusbet-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias focusbet
```

Create `android/keystore.properties` (already git-ignored):

```
storeFile=../../focusbet-release.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=focusbet
keyPassword=YOUR_KEY_PASSWORD
```

In `android/app/build.gradle` add above `android {`:

```gradle
def keystoreProps = new Properties()
def keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) keystoreProps.load(new FileInputStream(keystoreFile))
```

and inside `android {`:

```gradle
signingConfigs {
    release {
        if (keystoreFile.exists()) {
            storeFile file(keystoreProps['storeFile'])
            storePassword keystoreProps['storePassword']
            keyAlias keystoreProps['keyAlias']
            keyPassword keystoreProps['keyPassword']
        }
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false
    }
}
```

(merge with the existing `buildTypes` block rather than duplicating it). Raise `versionCode` and `versionName` in the same
file for every upload. Then:

```bash
npm run android:release-apk    # android/app/build/outputs/apk/release/app-release.apk  (sideloading, testers)
npm run android:release-aab    # android/app/build/outputs/bundle/release/app-release.aab (upload this to Google Play)
```

Check the signature: `apksigner verify --verbose android/app/build/outputs/apk/release/app-release.apk`.
Google Play requires the `.aab`; the `.apk` is for direct installs.

Or use Android Studio: `npm run android:open`, then Build > Generate Signed Bundle / APK.

## 6. iOS (needs a Mac with Xcode)

```bash
npx cap add ios
npm run ios:open        # opens Xcode: set your Team, bundle id, then Product > Archive
```

In `ios/App/App/Info.plist` also add `NSUserTrackingUsageDescription` and Google's `SKAdNetworkItems` list
(AdMob docs). iOS has no screen-off broadcast, so a lock currently counts as leaving the app until you add a native
plugin (`protectedDataWillBecomeUnavailable`).

## FlutterFlow and Cordova

* **FlutterFlow** builds Flutter apps. It cannot import this React project, so it is not an option for this codebase.
* **Cordova** also works, but needs the Cordova flavour of every plugin (`cordova-plugin-admob-plus` instead of
  `@capacitor-community/admob`, and so on) and rewrites of `services/ads.js`, `storage.js`, `lifecycle.js`. Capacitor is the
  supported path here.

## Coin rewards

A completed bet earns `ECONOMY.coinsPerMinute` (2) coins per focused minute, except the lengths listed in `ECONOMY.rewardByMinutes`:
5 min = 10, 10 min = 20, 15 min = 30, 25 min = 50, 30 min = 60, 45 min = 75, 60 min = 90.
Each preset button shows its reward. The rewarded ad doubles that session's reward. A failed bet still costs `ECONOMY.betCost` coins.

## Opening screens

Every launch plays a short animated splash (`components/Welcome/SplashScreen.jsx`). New players then see a 3-slide tour
(`Onboarding.jsx`, text comes from the numbers in `appConfig.js`); it is skipped for anyone who already has saved progress.
The home screen has a time-of-day greeting, a soft glow, and a glowing ring while a bet runs. Reduced-motion settings are respected.

## Running in the browser

`npm run dev`. Ads, payment and the rewarded video are simulated. The Android-only lock detection is not available.

## Code review: what was fixed

* **Dial stuck at 00:00** after a win (both "Awesome" and the double-coins path). It now returns to the chosen time.
* **Double penalty**: two events arriving together (grace timer plus app-background) could charge a bet twice. Failing is now
  ignored unless a bet is active.
* **Give Up while paused** could restart a stale grace timer. It is now only possible from a running bet.
* **Quit message** always said "streak was reset" even when a Streak Freeze Shield saved it.
* **Rewarded-ad overlay** restarted its countdown on every parent re-render and could grant the reward twice. It now uses a
  stable handler and a one-shot guard.
* **Storage writes** could finish out of order, so an older save could overwrite a newer one. Writes are now serialised and
  snapshotted when queued.
* **Saved data** is validated on load, so corrupted storage cannot produce negative coins or a broken streak.
* **Shop**: an owned item (or a second Shield) can no longer be charged for twice.
* **Streak**: one day per calendar day; moving the clock backwards no longer farms streak days.
* **Deals fetch** reads a live CSV/JSON link, has a 10-second timeout (no endless spinner), drops malformed rows, and only opens https links.
* **Purchase flow** can no longer hang on "Processing" when billing throws; release builds never grant a mock purchase.
* **Lifecycle listeners** are removed correctly even if the app unmounts before the native listener finishes registering.
* **Ad calls** run in order and never throw into the UI.
* **Accessibility**: dialogs trap and restore focus and have proper roles; the shop has real tabs and closes with Escape;
  buttons announce what they do ("Buy Zen Forest Ambient Sound for 500 coins, not enough coins"); decorative icons and
  emoji are hidden from screen readers; touch targets are at least 44px; long toasts wrap; reduced-motion users get no confetti.
* **Wording**: friendlier, encouraging messages ("You've got this", "Every focused minute counts"), a clearer empty streak,
  and honest "Shield ready" wording.

## Known limits

* Coins, streak and purchases live on the phone. A determined user can edit them; for real value (affiliate redemptions) add a
  server check. Changing the date between bets can still earn an extra streak day without a server clock.
* Lock-screen grace needs the native plugin (Android snippet included, iOS not).
* This project has not been compiled in this environment (no network for `npm install`). Every file was syntax-checked and
  every import verified, but run `npm install && npm run build` first and fix any version drift in `package.json`.
