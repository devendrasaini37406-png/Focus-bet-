package com.yourcompany.focusbet; // <- change to your appId package

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(ScreenStatePlugin.class); // must come before super.onCreate
    super.onCreate(savedInstanceState);
  }
}
