package com.yourcompany.focusbet; // <- change to your appId package

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Tells the web layer when the screen turns off, so a lock gets the 3-second grace period. */
@CapacitorPlugin(name = "ScreenState")
public class ScreenStatePlugin extends Plugin {
  private BroadcastReceiver receiver;

  @Override
  public void load() {
    receiver = new BroadcastReceiver() {
      @Override
      public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
          notifyListeners("screenOff", new JSObject());
        }
      }
    };
    ContextCompat.registerReceiver(
      getContext(),
      receiver,
      new IntentFilter(Intent.ACTION_SCREEN_OFF),
      ContextCompat.RECEIVER_NOT_EXPORTED
    );
  }

  @Override
  protected void handleOnDestroy() {
    if (receiver != null) {
      getContext().unregisterReceiver(receiver);
      receiver = null;
    }
  }
}
