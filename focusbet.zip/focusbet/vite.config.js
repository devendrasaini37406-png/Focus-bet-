import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './', // required so the app loads from file-like origins inside Capacitor
  build: { outDir: 'dist', target: 'es2019' },
  server: { host: true },
});
