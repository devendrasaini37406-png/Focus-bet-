/**
 * FocusBet withdrawal requests -> Google Sheet.
 *
 * Setup (once):
 *  1. Open the PRIVATE sheet "FocusBet Withdrawals" (tab "Withdrawals", never share it publicly).
 *  2. Extensions > Apps Script. Paste this file over everything in Code.gs. Save.
 *  3. Deploy > New deployment > type "Web app".
 *       Execute as: Me      Who has access: Anyone
 *  4. Authorise when asked, copy the Web app URL (ends in /exec) into WITHDRAWAL.url in
 *     src/config/appConfig.js (or VITE_WITHDRAW_URL in .env), then rebuild the app.
 *  After editing this script later, use Deploy > Manage deployments > Edit > New version.
 */
const SHEET_NAME = 'Withdrawals';
const AMOUNT = '₹10'; // fixed on the server, so the app can't ask for more
const UPI_RE = /^[a-z0-9][a-z0-9._-]{1,255}@[a-z][a-z0-9]{1,63}$/;
const ID_RE = /^[a-z0-9_-]{8,64}$/i;

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(15000);
    const data = JSON.parse(e.postData.contents);
    const id = String(data.id || '');
    const upi = String(data.upiId || '').trim().toLowerCase();
    if (!ID_RE.test(id) || !UPI_RE.test(upi)) return reply({ ok: false, error: 'invalid' });

    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    const rows = sheet.getLastRow() - 1;
    if (rows > 0) {
      const ids = sheet.getRange(2, 5, rows, 1).getValues().flat();
      if (ids.indexOf(id) !== -1) return reply({ ok: true, duplicate: true }); // already recorded, safe to retry
    }
    // Timestamp | UPI ID | Amount | Status | Request ID
    sheet.appendRow([new Date(), upi, AMOUNT, 'Pending', id]);
    return reply({ ok: true });
  } catch (err) {
    return reply({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet() {
  return reply({ ok: true, service: 'FocusBet withdrawals' });
}

function reply(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
